package com.example.cineurubufinal;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class LoginController {
    @FXML
    private PasswordField PasswordTXT;

    @FXML
    private TextField UsarnameTXT;

    @FXML
    private Button cancel;

    @FXML
    private Button login;

    @FXML
    private Label cadastrese;

    private Stage stage;
    private Scene scene;
    private Parent root;



    public void hover(MouseEvent event) throws  IOException{
        cadastrese.getStylesheets().add(Objects.requireNonNull(getClass().getResource("Hover.css")).toExternalForm());
    }

    public void ahover(MouseEvent event) throws  IOException{
        cadastrese.getStylesheets().remove(Objects.requireNonNull(getClass().getResource("Hover.css")).toExternalForm());
    }


    @FXML
    public void trocaCadastro(MouseEvent event) throws IOException {
        SceneCreator.launchScene("Cadastro.fxml");
    }
    @FXML
    public void trocaCena3(ActionEvent event) throws IOException {
        SceneCreator.launchScene("Home.fxml");
    }



}
