package com.example.cineurubufinal;

import com.example.cineurubufinal.beans.Assento;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class HomeController implements Initializable {
    @FXML
    private ImageView Barbie;

    @FXML
    private ImageView BesouroAzul;

    @FXML
    private ImageView Elementos;

    @FXML
    private ImageView OpenHeimer;

    @FXML
    private ImageView Perfil;

    @FXML
    private Button faz;

    @FXML
    private Label login;

    private Stage stage;
    private Scene scene;
    private Parent root;
    String cssG = Objects.requireNonNull(this.getClass().getResource("cssG.css")).toExternalForm();

    public void initialize(URL location, ResourceBundle resources) {
    }
    @FXML
    public void trocaLogin(MouseEvent event) throws IOException {
        SceneCreator.launchScene("Login.fxml");
    }

    @FXML
    public void trocaBarbie(MouseEvent event) throws IOException {
        SceneCreator.launchScene("Barbie.fxml");
    }

    @FXML
    public  void trocaBesouro (MouseEvent event) throws IOException{
        SceneCreator.launchScene("Besouro.fxml");
    }
    @FXML
    public  void trocaOppehiemer (MouseEvent event) throws IOException{
        SceneCreator.launchScene("Oppenheimer.fxml");
    }
    @FXML
    public  void trocaElementos (MouseEvent event) throws IOException{
        SceneCreator.launchScene("Elementos.fxml");
    }
    public void hover(MouseEvent event) throws  IOException{
        login.getStylesheets().add(Objects.requireNonNull(getClass().getResource("Hover.css")).toExternalForm());
    }


    public void ahover(MouseEvent event) throws  IOException{
        login.getStylesheets().remove(Objects.requireNonNull(getClass().getResource("Hover.css")).toExternalForm());
    }

    @FXML
    public void trocaDadosPessoais(MouseEvent event) throws IOException {
        SceneCreator.launchScene("DadosPessoais.fxml");
    }
}
