package com.example.cineurubufinal.exception;

public class AssentoOcupadoException extends Exception{
    public AssentoOcupadoException(){
        super("Assento ocupado!");
    }
}
