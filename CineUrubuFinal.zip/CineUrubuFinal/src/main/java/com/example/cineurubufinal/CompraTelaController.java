package com.example.cineurubufinal;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import java.io.IOException;
import java.lang.reflect.AccessFlag;

public class CompraTelaController {

    @FXML
    public void trocaHome (ActionEvent event) throws IOException{
        SceneCreator.launchScene("Home.fxml");
    }
}
