package br.com.questao1;

public class teste {
    public static void main(String[] args) {
        Jogo2 jogo2 = new Jogo2();
        jogo2.resultados();
    }
}
